import React, { Component } from "react";
class index extends Component{
    render(){
        console.log("From employment", this.props.content);
        return(
            <div>

            </div>
        )
    }
}

export default index;
